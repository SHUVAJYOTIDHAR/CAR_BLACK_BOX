/* 
 * File:   display.h
 * Author: PERSONAL
 *
 * Created on November 12, 2020, 10:46 AM
 */

#ifndef DISPLAY_H
#define	DISPLAY_H

void display_dash_board( char event[],unsigned char speed);
void log_car_event(char event[],unsigned char speed);
char  login(char key ,char reset_flag);
char login_menu(char key,char reset_flag);


#endif	/* DISPLAY_H */

