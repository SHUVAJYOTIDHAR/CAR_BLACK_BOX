/* 
 * File:   24C02.h
 * Author: PERSONAL
 *
 * Created on November 15, 2020, 12:24 PM
 */

#ifndef 24C02_H
#define	24C02_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* 24C02_H */

