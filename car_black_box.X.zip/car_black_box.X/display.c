/*
 * File:   display.c
 * Author: PERSONAL
 *
 * Created on November 12, 2020, 10:39 AM
 */


#include <xc.h>
#include<string.h>
#include"clcd.h"
#include"ds1307.h"
#include"EEprom.h"
#include"display.h"
#include"digital_keypad.h"
#include"main.h"
#include "timer2.h"

#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
unsigned char clock_reg[3];
char time[7];
char log[10];//To log the event and speed in the external EEPROM(24C02)
int pos= -1;
extern int sec;
extern int return_time;
char *menu[] = {"view log","clear log","Download log ","set time ","change password"};
                // 0           1            2             3             4
//function to display the screen
static void  get_time()
{
    clock_reg[0] = read_ds1307(HOUR_ADDR);//read the hour from address 0x02
    clock_reg[1] = read_ds1307(MIN_ADDR);//read the min from the address 0x01
    clock_reg[2] = read_ds1307(SEC_ADDR);//read the sec from the address 0x01
    time[0] = ((clock_reg[0] >> 4) & 0x03) + '0';
    time[1] = (clock_reg[0] & 0x0F) + '0';//convert the hour into ascii value charecter 
    
    time[2] = ((clock_reg[1] >> 4) & 0x07) + '0';
    time[3] = (clock_reg[1] & 0x0F) + '0';
    
    time[4] = ((clock_reg[2] >> 4) & 0x07) + '0';
    time[5] = (clock_reg[2] & 0x0F) + '0';
    time[6] = '\0';
}
    

static void display_time(void)
{
    //Function to get the current time 
    get_time();
    
    clcd_putch(time[0],LINE2(2));
    clcd_putch(time[1],LINE2(3));
    clcd_putch(':',LINE2(4));
    clcd_putch(time[2],LINE2(5));
    clcd_putch(time[3],LINE2(6));
    clcd_putch(':',LINE2(7));
    clcd_putch(time[4],LINE2(8));
    clcd_putch(time[5],LINE2(9));
    
}
void display_dash_board( char event[] , unsigned char speed)
{
    clcd_print("  TIME     E  SP",LINE1(0));
    //to display the event 
    clcd_print(event,LINE2(11));
    //TO display the speed in the 14th location of clcd 
    clcd_putch(speed / 10 + '0',LINE2(14));// to convert the speed value of into the single digit 
    clcd_putch(speed % 10 + '0',LINE2(15));//To convert the speed into integer
    
    //To display current time 
    display_time();
}
void log_event()
{
     unsigned char addrs;
    if(++pos == 10)// 0 to 9 logs 
    {
        pos = 0;//after storing 10 bytes start overwrite from initial position 
    }
    addrs= pos *10 + 5;//store the log data from the fifth location of the ext EEPROM 
    ext_eeprom_24C02_str_write(addrs,log);// store the data 5 to 14 16 to 25  26 to 35 
    
}
void log_car_event(char event[],unsigned char speed)
{
    //log[] hhmmsson99
    get_time();//time : HHMMSS
    strncpy(log,time,6);//To store time in first 6 location of the log array 
    strcpy(&log[6],event);//To store the event in the 6th and 7th place 
    log[8]=speed/10 + '0';
    log[9]=speed%10 + '0';
    log_event();
}
void get_password(char *spassword)
{
    for(int i = 0 ; i < 5;i++)
    {         
        spassword[i]=ext_eeprom_24C02_read(i);
    }
}
char login(char key ,char reset_flag)
{
    char spassword[5];
    static char npassword[5];
    static char i = 0;
    static unsigned char attempt_rem;
    if(reset_flag == RESET_PASSWORD)
    {
        key = ALL_RELEASED;
        attempt_rem = 3;
        i = 0;
        sec = 0;
        npassword[0] = 0;
        npassword[1] = 0;
        npassword[2] = 0;
        npassword[3] = 0;
        npassword[4] = '\0';
         return_time = 5;
     
    }
    if(return_time == 0)
    {
        return RETURN_BACK;
    }
    
    if (key == SW4  && i < 5 )
    {
        return_time = 5;
        npassword[i] = '1';
        clcd_putch('*',LINE2(6 + i));
        i++;
    }
    else if(key == SW5  && i < 5 )
    {
        return_time = 5;
        npassword[i] = '0';
        clcd_putch('*',LINE2(6 + i));
        i++;
    }
    if(i == 5)
    {
        get_password(spassword);
        if(strcmp(npassword,spassword) == 0)// if password compare correct then return Login success   
        {        
             return LOGIN_SUCCESS;   
        } 
    else
    {     
       if(--attempt_rem == 0 )
            {
                clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                    __delay_us(500);
                clcd_print("You are blocked",LINE1(0));
                clcd_print("wait for ..60sec",LINE2(0));
                sec = 60;
                while(sec)
                {
                    clcd_putch(sec / 10 + '0',LINE2(11)); 
                    clcd_putch(sec % 10 + '0',LINE2(12)); 
                }
                attempt_rem = 3;
                   
            }
            else
            {
                clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                      __delay_us(500);
                clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
                     __delay_us(100);      
                clcd_print(" WRONG PASSWORD ",LINE1(0));
                clcd_putch(attempt_rem + '0',LINE2(0));
                clcd_print("attempt Remains",LINE2(2));
                 sec = 3;
                 while(sec); //blocking delay 
            }
         clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
             __delay_us(500);
        clcd_print(" ENTER PASSWORD ",LINE1(0));
           i = 0;
       return_time = 5;    
    }
    }
    return 0x10;//if login not success then return 0x10 ;
}

    
char login_menu(char key,char reset_flag)
{
    static char menu_pos = 0;//index for the menu array that can be varying 
    static char select_pos = 1;
    if(reset_flag == RESET_LOGIN_MENU)
    {
        menu_pos = 0;
        select_pos = 1;
      clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
       __delay_us(500);      

    }
    if(key == SW4  && menu_pos > 0)
    {
        menu_pos--;//since in clcd data stored horizontally for that reason menu pos are decrement by one position 
        select_pos = 1;
        clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
        __delay_us(500);
    } 
    else if(key == SW5  && menu_pos < 4)
    {
        menu_pos++; //here also the same case data stored horizontally for that reason  
        select_pos = 0;
        clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
             __delay_us(500);
    }
    if(select_pos == 1)// sw4 are to be selected 
    {
        clcd_putch('*',LINE1(0));
        clcd_print(menu[menu_pos],LINE1(2));
        clcd_print(menu[menu_pos + 1],LINE2(2));
    }
    else // sw5 are to be selected 
    {
        clcd_putch('*',LINE2(0));
        clcd_print(menu[menu_pos - 1],LINE2(2));
        clcd_print(menu[menu_pos], LINE2(2));
    }
    return menu_pos;
}
