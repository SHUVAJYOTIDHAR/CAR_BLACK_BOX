/*
 * File:   digital_keypad.c
 * Author: PERSONAL
 *
 * Created on November 15, 2020, 3:19 PM
 */


#include <xc.h>
#include"digital_keypad.h"
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
void init_digital_keypad(void) {

     KEYPAD_PORT_DDR = KEYPAD_PORT_DDR | INPUT_LINES;// TRISB | 0X3F by using or portb of 6 switches taken as input
    /*write your initialization*/
}
 unsigned char read_digital_keypad(unsigned char mode)
{
    static unsigned char once = 1;
    
    if (mode == LEVEL_DETECTION) // IN CASE OF LEVEL DETECTION SWITCH OPERATE IN LOW LEVEL UNTIL RELEASED 
    {
        return KEYPAD_PORT & INPUT_LINES;// PORTB & 0X3FF
    }
    else   // STATE DETECTION  THAT OPERATE IN LOW LEVEL ONCE A SEC
    {
        if (((KEYPAD_PORT & INPUT_LINES) != ALL_RELEASED) && once) //PORTB & 0X3FF != 0X3FF
        {
            once = 0; // TO OPERATE IN LOW LEVEL ONCE DUE TO THAT ONCE VARIABLE IS TAKEN
            
            return KEYPAD_PORT & INPUT_LINES;// PORTB & 0X3F;
        }
        else if ((KEYPAD_PORT & INPUT_LINES) == ALL_RELEASED) //PORTB & 0X3FF == 0X3FF ( SW == 1)
        {
            once = 1;
        }
    }
    
    return ALL_RELEASED;//0X3FF;
}


