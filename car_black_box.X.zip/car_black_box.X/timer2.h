/* 
 * File:   timer2.h
 * Author: Shuvajyoti Dhar 
 *
 * Created on November 18, 2020, 10:48 AM
 */

#ifndef TIMER2_H
#define	TIMER2_H

void init_timer2(void);

#endif	/* TIMER2_H */

