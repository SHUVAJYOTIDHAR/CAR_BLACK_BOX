/* 
 * File:   ADC.h
 * Author: PERSONAL
 *
 * Created on November 2, 2020, 4:19 PM
 */

#ifndef ADC_H
#define	ADC_H

void init_adc(void);
unsigned short read_adc(void);

#endif	/* ADC_H */

